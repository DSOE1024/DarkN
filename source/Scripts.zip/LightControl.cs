using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightControl : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            //��������
            AddCont.Instance.AddLightCont();
            //ɾ���Լ�
            Destroy(gameObject);
        }
    }
}
