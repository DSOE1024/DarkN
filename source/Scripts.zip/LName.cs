using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LName : MonoBehaviour
{
    //�ؿ�����
    public Text lname;
    public string indexname;

    // Start is called before the first frame update
    void Start()
    {
        lname.text = indexname;
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
