﻿﻿using System;
using System.Collections.Generic;
using System.Text;
/**
* Copyright (c) 2018 Tencent Cloud. All rights reserved.
* 11/21/2018 2:51:13 PM
* bradyxiao
*/
namespace COSXML.Network
{
    public sealed class RetryStrategy
    {
    }
}
