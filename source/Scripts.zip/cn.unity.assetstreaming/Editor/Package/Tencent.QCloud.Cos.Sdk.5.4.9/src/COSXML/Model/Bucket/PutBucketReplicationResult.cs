﻿﻿using System;
using System.Collections.Generic;

using System.Text;

namespace COSXML.Model.Bucket
{
    public sealed class PutBucketReplicationResult : CosResult
    {

    }
}
