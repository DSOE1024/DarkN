﻿﻿using System;
using System.Collections.Generic;

using System.Text;
/**
* Copyright (c) 2018 Tencent Cloud. All rights reserved.
* 11/2/2018 9:04:44 PM
* bradyxiao
*/
namespace COSXML.Model.Bucket
{
    /// <summary>
    /// 删除 空 Bucket返回的结果
    /// </summary>
    public sealed class DeleteBucketResult : CosResult
    {
    }
}
