﻿﻿

namespace COSXML.Model.Bucket
{
    public sealed class DeleteBucketWebsiteResult : CosResult
    {
    }
}
