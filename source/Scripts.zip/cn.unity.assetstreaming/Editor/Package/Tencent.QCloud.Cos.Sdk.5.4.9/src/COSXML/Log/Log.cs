﻿﻿using System;
using System.Collections.Generic;

using System.Text;

namespace COSXML.Log
{
    public interface Log
    {
        void PrintLog(string message);
    }
}
