

namespace COSXML.Model.Bucket
{
    public sealed class DeleteBucketTaggingResult : CosResult
    {
    }
}
