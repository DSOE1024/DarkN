﻿﻿using System;
using System.Collections.Generic;

using System.Text;
/**
* Copyright (c) 2018 Tencent Cloud. All rights reserved.
* 11/6/2018 10:58:01 AM
* bradyxiao
*/
namespace COSXML.Utils
{
    public sealed class HttpDateTimeUtils
    {
        
    }
}
