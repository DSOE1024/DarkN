using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ReStart : MonoBehaviour
{
    public int returnScene;
    // Start is called before the first frame update
    void Start()
    {
        Button btn = this.GetComponent<Button>();
        btn.onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        returnScene = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(returnScene);
    }

    
    void Update()
    {
        
    }
}
