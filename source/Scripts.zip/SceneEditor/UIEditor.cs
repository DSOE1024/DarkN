using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIEditor : MonoBehaviour
{
    public SceneEditor sceneEditor;
    //����Killbot
    public Button addKillbot;
    //����Lightbox
    public Button addLightbox;
    //�������λ��
    public Vector3 playerposition;
    //���
    public GameObject Player;
    void Start()
    {
        addKillbot.onClick.AddListener(AddKiller);
        addLightbox.onClick.AddListener(AddBox);
    }

    void Update()
    {
        //�ҵ���ǩΪPlayer
        Player = GameObject.FindWithTag("Player");
        //��ȡV3����
        playerposition = Player.transform.position;
        
    }
    void AddKiller()
    {
        sceneEditor.boxdata.boxList.Add(new Box { position = playerposition, type = 0 });
        Debug.Log("���ӳɹ�");
    }

    void AddBox()
    {
        sceneEditor.boxdata.boxList.Add(new Box { position = playerposition, type = 1 });
        Debug.Log("���ӳɹ�");
    }
    
}
