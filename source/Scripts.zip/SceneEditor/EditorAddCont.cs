using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EditorAddCont : MonoBehaviour
{
    public static EditorAddCont Instance;
    //����
    private int LightCont;
    //��������
    public int QNum;
    //��ʾ����
    public Text LightNum;

    void Awake()
    {
        Instance = this;
    }

    void Update()
    {
        LightNum.text = LightCont.ToString();


    }


    public void AddLightCont()
    {
        //���Ӹ���
        LightCont++;
        //�������Nö���
        if (LightCont >= QNum)
        {
            EditorQuestManager.Instance.Gohome();

        }

    }
}
