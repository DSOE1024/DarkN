using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

[Serializable]
public class Box
{
    //����
    public int type;
    //λ��
    public Vector3 position;
}

[Serializable]
public class Boxdata
{
    public List<Box> boxList;
}
public class SceneEditor : MonoBehaviour
{
    //���б�
    //public List<Box> boxList;
    public Boxdata boxdata;
    //Json���л�����
    public string jsonText;

    //���水ť
    public Button saveBt;

    //��ȡ��ť
    public Button loadBt;

    //killbot (0)
    public GameObject killbot;
    //lightbox (1)
    public GameObject lightbox;

    void Start()
    {
        //��ť���Ӽ���
        saveBt.onClick.AddListener(SaveObj);
        loadBt.onClick.AddListener(Load);
        
    }
    //�洢
    void SaveObj()
    {
        jsonText = JsonUtility.ToJson(boxdata);
    }

    //��ȡ
    void Load()
    {
        boxdata = JsonUtility.FromJson<Boxdata>(jsonText);
        for (int i =0;i < boxdata.boxList.ToArray().Length; i++)
        {
            //����
            if (boxdata.boxList[i].type == 0)
            {
                killbot.transform.position = boxdata.boxList[i].position;
                killbot = Instantiate(killbot);
            }
            if (boxdata.boxList[i].type == 1)
            {
                lightbox.transform.position = boxdata.boxList[i].position;
                lightbox = Instantiate(lightbox);
            }
        }
    }
}
