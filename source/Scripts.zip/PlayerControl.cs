using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    private Rigidbody rBody;
    public Joystick joystick;
    // Start is called before the first frame update
    void Start()
    {
        rBody = GetComponent<Rigidbody>();

    }


    void Update()
    {
#if UNITY_ANDROID || UNITY_IOS
        float horizontal = joystick.Horizontal;
        float vertical = joystick.Vertical;
        
#endif
#if UNITY_STANDALONE_WIN
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");
#endif


        Vector3 dir = new Vector3(horizontal, 0, vertical);
        if (dir != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(dir);
            rBody.velocity = 3 * dir.normalized;
        }
        else
        {
            rBody.velocity = Vector3.zero;
        }
    }
}
