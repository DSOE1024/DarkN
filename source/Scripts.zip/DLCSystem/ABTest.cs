using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ABTest : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //�ļ�·��
        string path = Application.dataPath + "/AssetBundle/custom.ab";
        //��ȡ�ļ�
        AssetBundle ab = AssetBundle.LoadFromFile(path);
        //����Ԥ�Ƽ�
        GameObject CubePre = ab.LoadAsset<GameObject>("Cube");
        //ʵ����
        Instantiate(CubePre);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
